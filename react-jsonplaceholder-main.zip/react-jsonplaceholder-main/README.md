# API jsonplaceholder

Projeto em React + Typescript
Criando o consumo de uma [API FAKE](https://jsonplaceholder.typicode.com) com rotas dinamicas e estaticas

Projeto desenvolvido durante o curso [B7Web](https://b7web.com.br)

### Instalação
- `npm install`

### Para rodar
- `npm start`