export type Tenant = {
  slug: string;
  name: string;
  mainColor: string;
  secondColor: string;
};
