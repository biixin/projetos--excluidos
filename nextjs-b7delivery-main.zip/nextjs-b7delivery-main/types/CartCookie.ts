export type CartCookie = {
    id: number;
    qt: number;
}