import { UserSocial } from "./UserSocial"

export type Props = {
    user: UserSocial
}