export type PostFriend = {
    
}