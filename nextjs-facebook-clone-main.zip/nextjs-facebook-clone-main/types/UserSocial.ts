

export type UserSocial = {
    name: string,
    email: string,
    image: string,
    uid?: string
}