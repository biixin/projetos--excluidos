export type User = {
    id: number,
    name: string,
    email: string,
    avatar: string
    background: string
    uid?: string
}