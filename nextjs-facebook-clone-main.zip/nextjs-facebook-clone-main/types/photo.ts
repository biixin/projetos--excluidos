export type Photo = {
    id: string;
    url: string;
    name: string;

}