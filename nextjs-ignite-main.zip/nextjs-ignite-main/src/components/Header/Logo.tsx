export function Logo() {
  return (
    <p className="text-3xl font-bold tracking-tight w-64 ">
      dashgo
      <span className="text-pink-500 ml-1">.</span>
    </p>
  )
}