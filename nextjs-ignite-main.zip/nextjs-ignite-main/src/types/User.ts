

export type User = {
  _id: string
  email: string;
  name: string;
  created_at: string;
};