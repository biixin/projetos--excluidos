# Lista de Tarefa

Projeto em React + Typescript
criando uma lista de tarefa durante o Projeto '5 Dias 5 Projetos'

Projeto desenvolvido durante o curso [B7Web](https://b7web.com.br)

### Instalação
- `npm install`

### Para rodar
- `npm start`