# Jogo da memoria

Projeto em React + Typescript
Fazendo um jogo da memoria no react.

Projeto desenvolvido durante o curso [B7Web](https://b7web.com.br)

### Instalação
- `npm install`

### Para rodar
- `npm start`
