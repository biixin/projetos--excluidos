


export type GridItemType = {
    item: number | null;
    shown: boolean;
    permanentShown: boolean;
    
}