<h1 align="center">API Facebook Clone em Desenvolvimento 🛠</h1>

Parte Back-End do projeto [Facebook Clone](https://github.com/saagas-code/nextjs-facebook-clone)

## Tecnologias utilizadas:
- Node
- Express
- Prisma

## 💻 Autor<br>
<table>
  <tr>
    <td align="center">
      <a href="https://github.com/saagas-code">
        <img src="https://avatars.githubusercontent.com/u/104795182?v=4" width="100px;" /><br>
        <sub>
          <b>Matheus Almeida</b>
        </sub>
      </a>
    </td>
  </tr>
</table>
