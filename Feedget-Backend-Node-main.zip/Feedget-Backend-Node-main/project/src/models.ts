import { PrismaFeedbackModel } from "./actions/contracts-implementation/prisma/models";


export const feedbackModel = new PrismaFeedbackModel()