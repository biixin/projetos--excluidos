export interface FeedbackModelDataType {
    type: string,
    comment: string,
    screenshot?: string
}