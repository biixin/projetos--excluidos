<h1 align="center">API nwl-return</h1>
Projeto realizado durante a nwl-return da rocketseat, onde projetamos a parte back-end de um widget para envio de feedback's para os devs, onde poderá ser um bug, ideia ou qualquer outra coisa.

<h2 id="tools">🛠️ Ferramentas</h2>

<ul>
<li>Node</li>
<li>Typescript</li>
<li>Mailtrap com Nodemailer</li>
<li>Prisma</li>
<li>Express</li>
<li>Jest para testes</li>
</ul>




### License

© [SaagaS](https://github.com/saagas-code)



