<h1 align="center">WEB nwl-return</h1>

Desenvolvido na semana do NWL return da RocketSeat, o FeedGet é um widget que posibilita o envio de feedbacks, com a posibilidade de fazer capturas de tela e enviar junto ao set feeback feito em React gerado em VITE + Tailwind

![](https://github.com/biixin/feedback-giff/blob/main/20221212_174322.gif)



## Instalação

**1 -** Rodar comandos no Terminal:
```sh
$ npm install
$ npm run dev
```

## License
© [SaagaS](https://github.com/SaagaS0)

