import { Widget } from "./components/Widget";

export function App() {
  return <Widget />
}