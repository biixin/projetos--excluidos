# BACK-END Roblox CLONE

Projeto em NodeJS + Typescript
Parte do Back-End do Projeto [GAME3RB Clone](x)

## Instalação
**1 -** Criar arquivo .env e setar variáveis:
```sh
$ PORT
$ MONGO_URL
$ JWT_SECRET_KEY
```
**3 -** Rodar comandos no Terminal:
```sh
$ npm install
$ npm run start-dev
```

### License
© [SaagaS](https://github.com/SaagaS0)
