
export type accounts = {
    _id: string,
    username: string,
    password: string
}

