import css from './template.module.css'
import registerBg from '../assets/registerbg.png'
import React, { useState } from 'react'
import {Link, useNavigate} from 'react-router-dom'
import {setUsername, setPassword, setDay, setMonth, setYear, setEmail, setGender} from '../redux/reducers/registerReducer'
import { useDispatch } from 'react-redux'




export const Register = () => {

    const[maleColor, setMaleColor] = useState('')
    const[femaleColor, setFemaleColor] = useState('')

    const[username, setUsernameInput] = useState('')
    const[password, setPasswordInput] = useState('')
    const[email, setEmailInput] = useState('')
    const[day, setDayInput] = useState('')
    const[month, setMonthInput] = useState('')
    const[year, setYearInput] = useState('')
    const[gender, setGenderInput] = useState('')
    

    // mudar o state payload
    const dispatch = useDispatch()
    const navigate = useNavigate()

    const changeUsername = (newUsernameState: string) => dispatch(setUsername(newUsernameState))
    const changeEmail = (newEmailState: string) => dispatch(setEmail(newEmailState))
    const changePassword = (newPasswordState: string) => dispatch(setPassword(newPasswordState))
    const changeDay = (newDayState: string) => dispatch(setDay(newDayState))
    const changeMonth = (newMonthState: string) => dispatch(setMonth(newMonthState))
    const changeYear = (newYearState: string) => dispatch(setYear(newYearState))
    const changeGender = (newGenderState: string) => dispatch(setGender(newGenderState))

    



    const handleMaleColor = () => {
        setMaleColor('blue')
        setFemaleColor('')
        setGenderInput('male')
    }
    const handleFemaleColor = () => {
        setFemaleColor('pink')
        setMaleColor('')
        setGenderInput('female')
    }

    const handleEmailInput = (e: React.ChangeEvent<HTMLInputElement>) => {
        setEmailInput(e.target.value)
    }
    const handleUsernameInput = (e: React.ChangeEvent<HTMLInputElement>) => {
        setUsernameInput(e.target.value)
    }
    const handlePasswordInput = (e: React.ChangeEvent<HTMLInputElement>) => {
        setPasswordInput(e.target.value)
    }
    const handleRegister = () => {
        if (username !== '' && email !== '' && password !== '') {
            changeEmail(email)
            changeUsername(username)
            changePassword(password)
            changeDay(day)
            changeMonth(month)
            changeYear(year)
            changeGender(gender)
            navigate('/login')
        } else {
            alert('Preencha os dados')
        }
    }
   
    
   

    return( 
        <div style={{backgroundImage: `url(${registerBg})`}} className={css.cadastroBody}>
            <div className={css.login}>
                <div className={css.loginText}><Link to={'/login'}>Iniciar Sessão </Link></div>
            </div>
            <div className={css.roblox}>Roblox</div>
            <div className={css.registro}>
                <div className={css.registroInfo}>
                    <span>CADASTRE-SE E COMECE A SE <br /> DIVERTIR!   </span>
                    
                    <form action="">
                        Data de Nascimento <br />
                        <select onChange={e => setDayInput(e.target.value)} className={css.First} name="Dia" id="">
                            <option value="Dia">Dia</option>
                            <option value='1'>1</option>
                            <option value="3">3</option>
                            <option value="4">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>

                            
                            
                        </select>
                        <select onChange={e => setMonthInput(e.target.value)} name="Mês" id="">
                            <option value="Mês">Mês</option>
                            <option value="Janeiro">Janeiro</option>
                            <option value="Fevereiro">Fevereiro</option>
                            <option value="Março">Março</option>
                            <option value="Abril">Abril</option>
                            <option value="Maio">Junho</option>
                            <option value="Julho">Julho</option>
                            <option value="Agosto">Agosto</option>
                            <option value="Setembro">Setembro</option>
                            <option value="Outubro">Outubro</option>
                            <option value="Novembro">Novembro</option>
                            <option value="Dezembro">Dezembro</option>
                        </select>
                        <select onChange={e => setYearInput(e.target.value)} name="Ano" id="">
                            <option value="Ano">Ano</option>
                            <option value="1990">1990</option>
                            <option value="1995">1995</option>
                            <option value="2000">2000</option>
                            <option value="2001">2001</option>
                            <option value="2005">2005</option>
                            <option value="2010">2010</option>
                            
                        </select>
                        
                    </form>
                    <div className={css.input3}>
                        <span>Email</span> <br />
                        <input onChange={handleEmailInput} placeholder='Digite seu email' type="text" />
                    </div>

                    <div className={css.input1}>
                        <span>Usuário</span> <br />
                        <input onChange={handleUsernameInput} placeholder='Não use o seu nome real' type="text" />
                    </div>

                    <div className={css.input2}>
                        <span>Senha</span> <br />
                        <input onChange={handlePasswordInput} placeholder='Minimo de 8 caracteres' type="text" />
                    </div>

                    

                    <div className={css.gender}>
                        <button style={{borderColor:maleColor}} onClick={handleMaleColor}>Male</button>
                        <button style={{borderColor:femaleColor}} onClick={handleFemaleColor}>Female</button>
                    </div>

                    <div className={css.termos}>
                    Ao clicar em Cadastrar-se, você aceita os <a>Termos de Uso</a> (incluindo a cláusula de arbitragem) e a <a>Política de Privacidade</a>.
                    </div>

                    <button onClick={handleRegister} className={css.cadastrar}>Cadastrar-se</button>
                    
                    
                </div>
            </div>
        </div>
    )
}
