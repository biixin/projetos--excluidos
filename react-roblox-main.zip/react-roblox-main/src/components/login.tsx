import css from './template.module.css'
import {Link, useNavigate} from 'react-router-dom'
import { ChangeEvent, useContext, useState } from 'react'
import { AuthContext } from '../contexts/Auth/AuthContext'

export const Login = () => {
    const auth = useContext(AuthContext)
    const navigate = useNavigate()

    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')

    const handlePasswordInput = (e: ChangeEvent<HTMLInputElement>) => {
        setPassword(e.target.value)
    }

    const handleLogin = async () => {
        if(email && password) {
            const isLogged = await auth.signin(email, password);
            if(isLogged) {
                navigate('/home')
            } else {
                alert("Falha ao logar.")
            }
        } else {
            alert('Preencha os dados !')
        }
    }

    return (
        <div className={css.loginBody}>
            <div className={css.loginArea}>
                <div className={css.loginSpace}>
                    <div className={css.info}>Inicie a sessão no Roblox</div>
                    <div className={css.loginForm}>
                        <form action="">
                            <input onChange={e => setEmail(e.target.value)} value={email} placeholder='Usuário/e-mail/telefone' type="text" /> <br />
                            <input onChange={handlePasswordInput} value={password} placeholder='Senha' type="password" /> <br />
                            <button onClick={handleLogin}><Link style={{color:'inherit', textDecoration:'none'}} to={'/home'}>Iniciar Sessão</Link></button>
                        </form>
                    </div>
                    <div className={css.recoverer}><a>Esqueceu a senha ou nome de usuário?</a></div>
                    <div className={css.createAccount}>
                        <div className={css.linha}></div>
                        <span>Iniciar sessão com</span>
                        <div className={css.linha}></div>
                    </div>
                    <button className={css.criarConta}>Outros Dispositivos Conectados</button>
                    <span>Não possui uma conta? <a><Link to={'/'}>Cadastrar-se</Link></a></span>
                </div>
            </div>
        </div>
    )
}