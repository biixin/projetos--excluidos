import { HeaderItem } from '../components/header'
import { SectionItem } from '../components/section';
import { ConfigItem } from '../components/config';

import css from '../components/template.module.css'

export const Config = () => {
    return (
        <div className={css.fundo4}>
            <HeaderItem/>
            <SectionItem/>
            <ConfigItem/>
        </div>
    )
}