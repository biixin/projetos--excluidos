import {Register} from '../components/register'


export const Cadastro = () => {
    return (
        <div>
            <Register/>
        </div>
    )
}