import { HeaderItem } from '../components/header'
import { SectionItem } from '../components/section';
import {GameItem} from '../components/game'


import css from '../components/template.module.css'

export const Game = () => {
    return (
        <div className={css.fundo5}>
            <HeaderItem/>
            <SectionItem/>
            <GameItem/>
        </div>
    )
}