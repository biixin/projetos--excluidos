import { HeaderItem } from '../components/header'
import { SectionItem } from '../components/section';
import { MainItem } from '../components/main';
import css from '../components/template.module.css'

export const Home = () => {
    return (
        <div className={css.fundo}>
            <HeaderItem/>
            <SectionItem/>
            <MainItem/>
        </div>
    )
}