import { HeaderItem } from "../components/header"
import {Login} from '../components/login'
import css from '../components/template.module.css'


export const Logar = () => {
    return (
        <div className={css.logarBody}>
            <HeaderItem/>
            <Login/>
        </div>
    )
}