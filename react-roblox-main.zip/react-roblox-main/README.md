# React ROBLOX

Projeto em React + Typescript 

Criando uma cópia do site [Roblox](https://b7web.com.br)

Treinando os conhecimentos adquiridos das aulas de react durante o curso [B7Web](https://b7web.com.br)



### Instalação
- `npm install`

### Para rodar
- `npm start`
